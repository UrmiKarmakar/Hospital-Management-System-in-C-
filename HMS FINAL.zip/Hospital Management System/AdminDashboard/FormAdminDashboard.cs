﻿using PatientDashboard.Forms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AdminDashboard
{
    public partial class FormAdminDashboard : Form
    {
        //We declare fields privately for the current button, a random number generator, a temporary index, and an active form

        //Fields are here
        private Button currentButton;
        private Random random;
        private int tempIndex;
        //Storing the forms No
        private Form activeForm;

        //Storing ID
        string adminID;
        public FormAdminDashboard(string adminID)
        {
            InitializeComponent();
            random = new Random();
            btnCloseChildForm.Visible = false;
            this.adminID = adminID;
        }


        //Methonds Declared
        private Color SelectThemeColor() // a method to select the theme color.
        {
            //We select a random color from the list of colors for the theme.
            int index = random.Next(ThemeColor.ColorList.Count);

            //If the color has already been selected, then we choose again to choose a different one.
            while(tempIndex == index)
            {
                index = random.Next(ThemeColor.ColorList.Count);
            }
            tempIndex = index; // storing the index into tempindex 
            string color = ThemeColor.ColorList[index]; // receiving the color code as string from the ColorList
            return ColorTranslator.FromHtml(color); // returning the color in valid format by traslating the html format color
        }


        private void ActiveButton(object btnSender) // We highlight the button that has been clicked
        {
            if (btnSender != null)
            {
                if(currentButton != btnSender)
                {
                    DisableButton(); //Deactivating the highlighting of the butter. AKA- Default values.

                    Color color = SelectThemeColor(); // Selecting a randoom color for the theme
                    currentButton = (Button)btnSender;
                    currentButton.BackColor = color; // Changing the backgroud color of the button into new randomly genarated color.
                    currentButton.ForeColor = Color.White; // Changing the text color of the button into white.
                    
                    // By highlighting a button, we increased the font size of the font-zoom effect (here at 14.5)
                    currentButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
                    panelTitleBar.BackColor = color;
                    panelLogo.BackColor = ThemeColor.ChangeColorBrightness(color,-0.3);


                    //We are saving the current theme colors here using property method of ThemeColor class
                    ThemeColor.PrimaryColor = color;
                    ThemeColor.SecondaryColor = ThemeColor.ChangeColorBrightness(color, -0.3); ;

                    btnCloseChildForm.Visible = true;


                }
            }

        }

        private void DisableButton()//Deactivating the highlighting of the butter. AKA- Default values.

        {
            foreach (Control previousBtn in panelMenu.Controls) //panelMenu is the menu on the left side
            {
                if (previousBtn.GetType() == typeof(Button)) 
                {
                    previousBtn.BackColor = Color.FromArgb(51, 51, 76); // 51, 51, 76 are the default set values of the buttons optained from grapical interface menu
                    previousBtn.ForeColor = Color.Gainsboro;  // Extracted from GUI -> properties -> font -> foreColor
                                                              // Must be a system defined color that as ASRGB value.
                    previousBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));

                }
            }
        }


        //We create a method to open he forms in the container pannel.

        private void OpenChildform(Form childForm, object btnSender)
        {
            if (activeForm != null)
            {
                activeForm.Close();
            }

            //ActiveButton(btnSender); // We highlight the active button. (active)
            activeForm = childForm;
            childForm.TopLevel = false;
            childForm.FormBorderStyle = FormBorderStyle.None;
            childForm.Dock = DockStyle.Fill;
            this.panelDesktopPanel.Controls.Add(childForm);
            this.panelDesktopPanel.Tag = childForm;
            childForm.BringToFront();
            childForm.Show();
            // Showing the title(text) of the child form in the title bar (labelTitle)
            labelTitle.Text = childForm.Text;
            // We will add forms to test this method!
        }


        private void AdminOverview_Click(object sender, EventArgs e)
        {
            //ActiveButton(sender);
            ActiveButton(sender); 

            OpenChildform(new Forms.FormOverview(), sender); 

        }

        private void btnDiaCentreAddRemove_Click(object sender, EventArgs e)
        {
            ActiveButton(sender);

            OpenChildform(new Forms.FormDiaAddRemove(), sender);


        }

        private void btnDoctorAddRemove_Click(object sender, EventArgs e)
        {
            ActiveButton(sender);

            OpenChildform(new Forms.FormDoctorAddRemove(), sender);


        }

        private void btnBill_Click(object sender, EventArgs e)
        {
            ActiveButton(sender);

            OpenChildform(new Forms.FormBill(), sender);

        }

        private void btnAdmin_Click(object sender, EventArgs e)
        {
            ActiveButton(sender);

            OpenChildform(new Forms.FormAdminProfile(), sender);
        }

        private void btnNotifications_Click(object sender, EventArgs e)
        {

            ActiveButton(sender);

            OpenChildform(new Forms.FormNotifications(), sender);
        }


        private void btnSettings_Click(object sender, EventArgs e)
        {
            ActiveButton(sender);

            OpenChildform(new Forms.FormSettings(), sender);
        }

        //Adding a button to close the child form and reseting to default values
        private void btnCloseChildForm_Click(object sender, EventArgs e)
        {
            if(activeForm != null)
            {
                activeForm.Close();
                Reset();
            }

        }
        private void Reset()
        {
            DisableButton();
            labelTitle.Text = "Admim Dashboard";
            panelTitleBar.BackColor = Color.FromArgb(0, 150, 136);
            panelLogo.BackColor = Color.FromArgb(39, 39, 58);
            currentButton = null;
            btnCloseChildForm.Visible = false;
        }

        private void labelTitle_Click(object sender, EventArgs e)
        {

        }

        private void panelTitleBar_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panelDesktopPanel_Paint(object sender, PaintEventArgs e)
        {
        }
    }


}
