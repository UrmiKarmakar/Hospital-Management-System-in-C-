﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AdminDashboard.Forms
{
    public partial class FormDiaAddRemove : Form
    {
        string cs = ConfigurationManager.ConnectionStrings["dbcs"].ConnectionString;
        string filterStr;
        public FormDiaAddRemove()
        {
            InitializeComponent();
            BindGridView(";");
        }

        private void FormDiaAddRemove_Load(object sender, EventArgs e)
        {
            LoadTheme();

        }

        private void LoadTheme() //We apply the colors of the current theme
        {
            foreach (Control btns in this.Controls)
            {
                if (btns.GetType() == typeof(Button))
                {
                    Button btn = (Button)btns;
                    btn.BackColor = ThemeColor.PrimaryColor;
                    btn.ForeColor = Color.White;
                    btn.FlatAppearance.BorderColor = ThemeColor.SecondaryColor;
                }
            }
            //label1.ForeColor = ThemeColor.PrimaryColor; 
            label2.ForeColor = ThemeColor.PrimaryColor;
            label3.ForeColor = ThemeColor.PrimaryColor; 
            label4.ForeColor = ThemeColor.PrimaryColor; 
            label5.ForeColor = ThemeColor.PrimaryColor;
        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Title = "Select Image";
            //ofd.Filter = "JPG File (*.jpg)| *.jpg ";
            ofd.Filter = "All Image File (*.*)| *.* ";

            if (ofd.ShowDialog() == DialogResult.OK)
            {
                pictureBox1.Image = new Bitmap(ofd.FileName);
            }
        }

        private void btnInsert_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(cs);
            string query = "insert DIA_INFO values(@id,@name,@address,@img)";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@id", txtDiaId .Text);
            cmd.Parameters.AddWithValue("@name", txtDiaName.Text);
            cmd.Parameters.AddWithValue("@address", richTextBox1.Text);
            cmd.Parameters.AddWithValue("@img", SavePhoto());
            con.Open();
            int a = cmd.ExecuteNonQuery();
            if (a > 0)
            {
                MessageBox.Show("Data Inserted Successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                BindGridView(";");
                ResetControl();
            }
            else
            {
                MessageBox.Show("Data Not Inserted!", "Fail", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            con.Close();
        }

        private byte[] SavePhoto()
        {
            MemoryStream ms = new MemoryStream();
            pictureBox1.Image.Save(ms, pictureBox1.Image.RawFormat);
            return ms.GetBuffer();
        }

        void BindGridView(string filterStr)
        {
            //Connection Between Gridview and Database
            SqlConnection con = new SqlConnection(cs);
            string query = "SELECT * FROM DIA_INFO"+ filterStr;
            SqlDataAdapter sda = new SqlDataAdapter(query, con);

            //Data in Gridview
            DataTable data = new DataTable();
            sda.Fill(data);
            dataGridView1.DataSource = data;

            //Image Column
            DataGridViewImageColumn dgv = new DataGridViewImageColumn();
            dgv = (DataGridViewImageColumn)dataGridView1.Columns[3];
            dgv.ImageLayout = DataGridViewImageCellLayout.Stretch;

            //Autosize Table Column
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            //Image Row Hight
            dataGridView1.RowTemplate.Height = 80;

        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(cs);
            string query = "update DIA_INFO set DIA_ID=@id,DIA_NAME=@name,DIA_ADDRESS=@address,DIA_IMG=@img where DIA_ID=@id";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@id", txtDiaId.Text);
            cmd.Parameters.AddWithValue("@name", txtDiaName.Text);
            cmd.Parameters.AddWithValue("@age", richTextBox1.Text);
            cmd.Parameters.AddWithValue("@img", SavePhoto());
            con.Open();
            int a = cmd.ExecuteNonQuery();
            if (a > 0)
            {
                MessageBox.Show("Data Updated Successfully!", "Update", MessageBoxButtons.OK, MessageBoxIcon.Information);
                BindGridView(";");
                ResetControl();
            }
            else
            {
                MessageBox.Show("Data Not Updated!", "Fail", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            con.Close();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(cs);
            string query = "delete from DIA_INFO where id=@id";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@id", txtDiaId.Text);
            con.Open();
            int a = cmd.ExecuteNonQuery();
            if (a > 0)
            {
                MessageBox.Show("Data Deleted Successfully!", "Delete", MessageBoxButtons.OK, MessageBoxIcon.Information);
                BindGridView(";");
                ResetControl();
            }
            else
            {
                MessageBox.Show("Data Not Deleted!", "Fail", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            con.Close();

        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            ResetControl();
        }

        void ResetControl()
        {
            txtDiaId.Clear();
            txtDiaName.Clear();
            richTextBox1.Clear();
            pictureBox1.Image = Properties.Resources.user;
        }

        private void dataGridView1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            txtDiaId.Text = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
            txtDiaName.Text = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
            richTextBox1.Text = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
            pictureBox1.Image = GetPhoto((byte[])dataGridView1.SelectedRows[0].Cells[3].Value);
        }

        private Image GetPhoto(byte[] photo)
        {
            MemoryStream ms = new MemoryStream(photo);
            return Image.FromStream(ms);
        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {
            string str = String.Format(" WHERE DIA_NAME LIKE '%{0}%';", txtSearch.Text);
            BindGridView(str);

        }
    }
}
