﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PatientDashboard.Forms
{
    public partial class FormFindDoc : Form
    {
        string cs = ConfigurationManager.ConnectionStrings["dbcs"].ConnectionString;
        string filterStr;

        public FormFindDoc()
        {
            InitializeComponent();
            BindGridView(";");

        }
        void BindGridView(string filterStr) // A Connection between GridView And database
        {
            SqlConnection con = new SqlConnection(cs);
            string query = "SELECT * FROM DOCTOR_INFO"+ filterStr;
            SqlDataAdapter s_da = new SqlDataAdapter(query, con);

            //Data in GridView
            DataTable data = new DataTable();
            s_da.Fill(data);
            dataGridView1.DataSource = data;

            //Fixing Image Column
            DataGridViewImageColumn dgv = new DataGridViewImageColumn();
            dgv = (DataGridViewImageColumn)dataGridView1.Columns[4];

            //Fixing Image layout
            dgv.ImageLayout = DataGridViewImageCellLayout.Stretch;


            //AutoSize Table Column
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            //Image Row height
            dataGridView1.RowTemplate.Height = 80;

        }

        private void FormCustomer_Load(object sender, EventArgs e)
        {
            //LoadTheme();
        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnDocterSearch_Click(object sender, EventArgs e)
        {
            string str = String.Format(" WHERE DOCTOR_NAME LIKE '%{0}%';", textBox1.Text);
            BindGridView(str);


        }

        private void button3_Click(object sender, EventArgs e)
        {

            if (comboBox2.Text.Length > 0)
            {
                string str = String.Format(" WHERE DOCTOR_NAME LIKE '%{0}%' AND SPECIALITIES = '%{1}%';", textBox1.Text, comboBox2.Text);
                BindGridView(str);
            }


        }
    }

}
