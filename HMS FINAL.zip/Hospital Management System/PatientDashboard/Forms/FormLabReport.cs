﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PatientDashboard.Forms
{
    public partial class FormLabReport : Form
    {
        public FormLabReport()
        {
            InitializeComponent();

        }
        private void LoadTheme() //We apply the colors of the current theme
        {
        }

        private void FormLabReport_Load(object sender, EventArgs e)
        {
            LoadTheme();

        }
    }
}
