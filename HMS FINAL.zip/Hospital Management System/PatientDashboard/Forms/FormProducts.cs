﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PatientDashboard.Forms
{
    public partial class FormProducts : Form
    {
        public FormProducts() // passing the LoadTheme() constructor here sometimes providing arbitrarily random values.
        {
            InitializeComponent();
        }

        private void LoadTheme() //We apply the colors of the current theme
        {
            foreach (Control btns in this.Controls)
            {
                if (btns.GetType() == typeof(Button)) // this is where the issue starts when passed via the constructor and sometimes its not changing at all whereas at other times the obtained values are different or ranmon
                {
                    Button btn = (Button)btns;
                    btn.BackColor = ThemeColor.PrimaryColor;
                    btn.ForeColor = Color.White;
                    btn.FlatAppearance.BorderColor = ThemeColor.SecondaryColor;
                }
            }
      
        }

        private void FormProducts_Load(object sender, EventArgs e) // but when the LoadTheme() function has been passed thorugh the load function of the form, it is working properly.
        {
            LoadTheme();
        }
    }
}
