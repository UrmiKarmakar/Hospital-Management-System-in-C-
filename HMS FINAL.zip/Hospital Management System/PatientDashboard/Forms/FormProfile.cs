﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PatientDashboard;
using System.Configuration;
using System.Data.SqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Reflection.Emit;
using System.IO;

namespace PatientDashboard.Forms
{
    public partial class FormProfile : Form
    {
        string cs = ConfigurationManager.ConnectionStrings["dbcs"].ConnectionString;

        //Storing Patient id;
        public string patient_id;
        MemoryStream ms;
        public FormProfile(string patient_id)
        {
            InitializeComponent();

            this.patient_id = patient_id;


            SqlConnection con = new SqlConnection(cs);

            string query = String.Format("SELECT * FROM Patient WHERE patient_ID = '{0}' ;", patient_id);

            SqlCommand cmd = new SqlCommand(query, con);
            con.Open();

            using (SqlDataReader dr = cmd.ExecuteReader())
            {
                if (dr.Read())
                {
                    patient_ID.Text = patient_id;
                    label11.Text = dr["patient_name"].ToString();
                    label12.Text = dr["patient_id"].ToString();
                    label13.Text = dr["patient_Gender"].ToString();
                    label14.Text = dr["patient_Contact_Info"].ToString();
                    label15.Text = dr["patient_Catagory"].ToString();
                    label16.Text = dr["patient_DOB"].ToString();
                    label17.Text = dr["patient_bloodGroup"].ToString();
                    richTextBox1.Text = dr["patient_address"].ToString();
                    richTextBox2.Text = dr["patient_Medical_Condition"].ToString();

                    byte[] picArr = (byte[])dr["patient_picture"];
                    ms = new MemoryStream(picArr);
                    ms.Seek(0,SeekOrigin.Begin);
                    pictureBox1.Image = Image.FromStream(ms);

                }

            }
        }

        private void btnUpdateInfo_Click(object sender, EventArgs e)
        {

            FormUpdateProfile formNew = new FormUpdateProfile(patient_ID.Text);
            formNew.Show();

        }
    }
}
