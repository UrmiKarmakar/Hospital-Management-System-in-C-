﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PatientDashboard
{
    public partial class FormTransction : Form
    {
        public FormTransction()
        {
            InitializeComponent();
        }
    }
}
