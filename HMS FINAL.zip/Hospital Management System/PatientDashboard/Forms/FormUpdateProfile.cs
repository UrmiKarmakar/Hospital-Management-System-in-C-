﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PatientDashboard.Forms
{
    public partial class FormUpdateProfile : Form
    {

        string cs = ConfigurationManager.ConnectionStrings["dbcs"].ConnectionString;

        //Storing Patient id
        public string patient_id;
        MemoryStream ms;
        string gender;


        public FormUpdateProfile(string patient_id)
        {
            InitializeComponent();
            this.patient_id = patient_id;


            SqlConnection con = new SqlConnection(cs);

            string query = String.Format("SELECT * FROM Patient WHERE patient_ID = '{0}' ;", patient_id);

            SqlCommand cmd = new SqlCommand(query, con);
            con.Open();

            using (SqlDataReader dr = cmd.ExecuteReader())
            {
                if (dr.Read())
                {
                    textBox2.Text = dr["patient_name"].ToString();
                    textBox1.Text = dr["patient_id"].ToString();
                    numericUpDown1.Text = dr["patient_Contact_Info"].ToString();
                    dateTimePicker1.Value = DateTime.ParseExact(dr["patient_DOB"].ToString(), "dddd, MMMM dd, yyyy", CultureInfo.InvariantCulture);
                    richTextBox1.Text = dr["patient_address"].ToString();
                    richTextBox2.Text = dr["patient_Medical_Condition"].ToString();

                    if (dr["patient_Gender"].ToString() =="Male")
                    {
                        radioButton1.Checked = true;
                    }
                    if (dr["patient_Gender"].ToString() == "Female")
                    {
                        radioButton1.Checked = true;
                    }
                    if (dr["patient_Gender"].ToString() == "None")
                    {
                        radioButton1.Checked = true;
                    }
                    byte[] picArr = (byte[])dr["patient_picture"];
                    ms = new MemoryStream(picArr);
                    ms.Seek(0, SeekOrigin.Begin);
                    pictureBox1.Image = Image.FromStream(ms);


                }
                con.Close();

            }
        }
        //private object SavePhoto() ::return type alternatives
        private byte[] SavePhoto()  //Converts the picture into byte
        {
            MemoryStream ms = new MemoryStream();
            pictureBox1.Image.Save(ms, pictureBox1.Image.RawFormat);

            return ms.GetBuffer();

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void btnSaveInfo_Click(object sender, EventArgs e)
        {

            SqlConnection con = new SqlConnection(cs);

            string query = "UPDATE Patient SET patient_ID=@patient_ID,patient_name=@patient_name,patient_address=@patient_address,patient_DOB=@patient_DOB,patient_Medical_Condition=@patient_Medical_Condition,patient_Gender=@patient_Gender,patient_Contact_Info=@patient_Contact_Info,patient_Catagory=@patient_Catagory,patient_picture=@patient_picture,patient_bloodGroup=@patient_bloodGroup";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@patient_ID", textBox1.Text);
            cmd.Parameters.AddWithValue("@patient_name", textBox2.Text);
            cmd.Parameters.AddWithValue("@patient_address", richTextBox1.Text);
            cmd.Parameters.AddWithValue("@patient_DOB", dateTimePicker1.Text);
            cmd.Parameters.AddWithValue("@patient_Medical_Condition", richTextBox2.Text);


            if (radioButton1.Checked == true)
            {
                radioButton1.Checked = true;
                gender = "Male";
            }
            if (radioButton1.Checked == true)
            {
                gender = "Female";
            }
            if (radioButton3.Checked == true)
            {
                gender = "None";
            }
            cmd.Parameters.AddWithValue("@patient_Gender", gender);
            cmd.Parameters.AddWithValue("@patient_Contact_Info", textBox3.Text);
            cmd.Parameters.AddWithValue("@patient_Catagory", numericUpDown1.Text);
            cmd.Parameters.AddWithValue("@patient_bloodGroup", comboBox1.Text);

            //Storing of image has to be done via passing bits
            cmd.Parameters.AddWithValue("@patient_picture", SavePhoto());

            con.Open();
            int a = cmd.ExecuteNonQuery();

            if (a > 0)
            {
                MessageBox.Show("Data Updated Successfully");
                this.Hide();
               // BindGridView();
                //ResetControl(); 

            }
            else
            {

                MessageBox.Show("Data Updated Failed");

            }
            con.Close();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog(); // Crteating an object of OpenFileDialog class
            ofd.Title = "Select Image"; // Setting the top menu title as following : "Select Image"
            ofd.Filter = "PNG File (*.png) | *.png"; // specifying the format of the Image file
            ofd.Filter = "JPG File (*.jpg,*.png) | *.jpg,*.png"; // Having multiple formats

            ofd.Filter = "All File (*.*) | *.*"; //ALTERNATIVE WAYSofd.ShowDialog(); 

            //ofd.ShowDialog();// Commanding to show the dialog accessing the method from the object


            if (ofd.ShowDialog() == DialogResult.OK)
            {
                pictureBox1.Image = new Bitmap(ofd.FileName);
                // Bitmap class is in system.drawing namespace where we did color related works before
            }
        }

        //reseting string data

        private void btnReset_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            numericUpDown1.Value = 0;
        }

        //reseting the image
        private void button4_Click(object sender, EventArgs e)
        {
            pictureBox1.Image = Properties.Resources.DUMMY_IMAGE;

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
    }
}
